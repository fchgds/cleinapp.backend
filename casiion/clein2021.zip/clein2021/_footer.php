<?php
?>
<br>
<footer class="container footer mt-auto py-3 ">
    <div class="row casii" style="height:5px"></div>
    <div class="d-flex flex-row">
        <div class="p-2 align-self-center flex-fill">
            <div class="">
                <p class="text-center">CLEIN © 2021</p>
            </div>
        </div>
        <div class="p-2 align-self-center flex-fill">
            <div class="">
                <p class="text-center">Contacto: </p>
            </div>
        </div>
        <div class="p-2 align-self-center flex-fill contacto">
            <p><a href="https://wa.me/56965678637">+56965678637</a></p>
            <p><a href="mailto://contacto@clein.org">contacto@clein.org</a></p>
        </div>
    </div>



</footer>
</body>
</html>
