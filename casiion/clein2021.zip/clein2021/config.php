<?php
define('DIR_BASE',      dirname( dirname( __FILE__ ) ) . '/');
define('DIR_SYSTEM',    DIR_BASE . 'app.clein.org/');
    echo $_SERVER['DOCUMENT_ROOT'];
