<?php
session_start();
echo $_SESSION['idusuario'];
echo "<br>";
print_r($_SESSION);
echo "<br>";
print_r($_SESSION['data']);
