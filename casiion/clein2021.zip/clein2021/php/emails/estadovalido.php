<div>
    <img src="http://app.clein.org/img/logo.png" width="300px">
    <p>
        Estimado/a <?php echo $nombre;?>
    </p>
    <p>
        Su pago ha sido validado con éxito.
    </p>
    <p>
        Tu registro está listo para que puedas participar del CASII-ON
    </p>
</div>
