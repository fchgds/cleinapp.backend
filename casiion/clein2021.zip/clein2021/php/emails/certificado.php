<div>
    <img src="http://app.clein.org/img/logo.png" width="300px">
    <p>
        Estimado/a <?php echo $nombre;?>
    </p>
    <p>
        Tu certificado del CASII-On está listo
    </p>
    <p>
        También lo puedes descargar de <a href="https://app.clein.org/certificado.php?c=<?php echo $codigo;?>">https://app.clein.org/certificado.php?c=<?php echo $codigo;?></a>
    </p>
</div>
