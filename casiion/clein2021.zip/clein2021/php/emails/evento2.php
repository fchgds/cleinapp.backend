<div>
    <img src="http://app.clein.org/img/logo.png" width="300px">
    <p>
        Estimado/a <?php echo $nombre;?>
    </p>
    <p>
        A partir del momento ya están habilitados en la app del CLEIN las actividades del CASII-ON en la pestaña Eventos.</p>
    <p> La app está disponible en web (app.clein.org) y Android.</p>
    <p> En esta app podrás ver la información de las sesiones del CASII-ON, ingresar a los talleres a través de los enlaces a Zoom, registrar tu asistencia al inicio y a la salida de los talleres, responder a las preguntas de trivia y registrar tu opinión en el formulario de satisfacción.</p>
    <p>
        El segundo taller CASII-ON es el siguiente:
    </p>
    <p>
        Eficiencia Energética Martes 30 de marzo hrs. 19.00
    </p>
    <p>
    <a href="https://reuna.zoom.us/j/82603966653?pwd=aXpMZkg5d2hiaU5ab1JqSlhnUWpHZz09">https://reuna.zoom.us/j/82603966653?pwd=aXpMZkg5d2hiaU5ab1JqSlhnUWpHZz09</a>
    </p>
    <p>
        Los esperamos a partir de las 18:40 hs Argentina-Chile / 17:40 hs Bolivia / 16:40 hs Perú / 15:40 hs México
    </p>
