<div>
    <img src="http://app.clein.org/img/logo.png" width="300px">
    <p>
        Estimado/a <?php echo $nombre;?>
    </p>
    <p>
        Su registro ha pasado al estado "Pendiente" por lo que en este momento puede realizar el pago.
    </p>
    <p>
        Ingrese a app.clein.org eligiendo la opción Registro Existente con su email y el número de documento y podrá observar las opciones de pago habilitadas
    </p>
    <p>
        Una vez realizado el pago, la organización lo validará y recibirá una notificación indicando que ha sido Validado.
    </p>
</div>
