<?php

use Medoo\Medoo;
$database = new Medoo([
    'database_type' => 'mysql',
    'database_name' => 'aleiiafc_appclein',
    'server' => 'localhost',
    'username' => 'aleiiafc_appclein',
    'password' => 't[1M8lnas7Et',
    'charset' => 'utf8',
    'collation' => 'utf8_general_ci',
]);
